import './gallery.css';
import  React from 'react';
import worksvg from '../img/works.png';



function Gallery() 
{
             
  return (
      <div className="gallery-container">
          <div className="header">
          <div className="gallery-title">
              <h2>Here Are Some Our Works For You!!</h2>
          </div>
          </div>
          <div className="cont">  
          <div className="gallery-content">
              <h4>
             Screen Foil Printing 
              </h4>
              <p id="parag">
                  Foil screen printing is similiar to traditional screen printing but an adhesive glue Ink is used instead of standard plastisol Inks . the foil is cut in squares off a large rool of foil . it is then placed over the glue adhesive print and heat pressed. The heat press activates the glue adhesive and grabs onto the foil
              </p>
          </div>       
           <div className="p-1">
                <div className="big">
                    <img id="img" src="http://greekcornerprinting.com/wp-content/uploads/2016/01/Shop-1.5.16_2.jpg" alt="big">
                    </img>
                </div>
                <div className="small-container">
                <div className="small">
                    <img  id="img" src="http://craftsmanave.com/v2/wp-content/uploads/2018/09/RHandt_0613_CA_ScreenPrinting_035.jpg" alt="small"></img>
                </div>
                <div className="small">
                    <img id="img" src="https://images.ctfassets.net/3wjbn0ndwf7t/26gDl9NFde06i6e8Y8aG64/c25e485d3bd12da7187f870f74ff85fb/How_to_Save_for_an_Indie_Screen_Printing_Setup.jpeg" alt="small"></img>
                </div>
                </div>
          </div>
         
          </div>

          <div className="cont"> 
          <div className="p-2">
                <div className="full-height-big">
                    <div className="block">
                    <img id="img" src="https://cdn.wallpapersafari.com/46/77/irWaSo.jpg" alt="big">
                    </img>
                    </div>
                </div>
                <div className="small-container-2">
                <div className="half-height-small">
                    <img id="img"src="https://wallpapercave.com/wp/wp2472313.jpg" alt="small"></img>
                </div>
                <div className="half-height-small">
                    <img id="img"src="https://wallup.net/wp-content/uploads/2017/03/29/496176-landscape-anime.jpg" alt="small"></img>
                </div>
                </div>
          </div>
          <div id="right-content" className="gallery-content">
              <h4>
              Screen fuse printing
              </h4>
              <p id="parag">
                 The fuse 1 is setting the new standard for SLS printing . It brings production-Ready technology once reserved for service bureus to your benchtop at a tench of the cost of industrial SLS  alternatives without compromising print quantity
              </p>
          </div>  
          </div>
          <div className="cont">  
          <div className="gallery-content">
              <h4>
              Screen Scrapper Printing 
              </h4>
              <p id="parag">
                 The aqueegee is used to squeeeze out the Ink on the screen, making it a leak-proof printing on a tool. in accordance with the diffrent uses, screen printing ink scraper can be piped into hand scaping board and machines scraper two.Scratch board by the rubber strip and fixture (handle) composed of two parts.
                   </p>

          </div>  
          <div className="p-1">
                <div className="big">
                    <img id="img"src="https://wallpapercave.com/wp/wp6199319.jpg" alt="big">
                    </img>
                </div>
                <div className="small-container">
                <div className="small">
                    <img id="img" src="https://wallpapercave.com/wp/wp3019570.jpg" alt="small"></img>
                </div>
                <div className="small">
                    <img id="img" src="https://cdn.wallpapersafari.com/31/6/g0EXTJ.jpg" alt="small"></img>
                </div>
                </div>
          </div>
          </div>

 </div>
  );
}
export default Gallery;
