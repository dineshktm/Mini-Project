import firebase from 'firebase';


 // Your web app's Firebase configuration
 var firebaseConfig = {
  apiKey: "AIzaSyB2QV16RC8bF-4m1HEZZCH55KPye07X3wY",
  authDomain: "login-signup-de2de.firebaseapp.com",
  projectId: "login-signup-de2de",
  storageBucket: "login-signup-de2de.appspot.com",
  messagingSenderId: "60080763082",
  appId: "1:60080763082:web:596a30b7c5e1e7f30ec433"
};
// Initialize Firebase
const fire = firebase.initializeApp(firebaseConfig);

export default fire; 

