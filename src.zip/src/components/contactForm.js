import emailjs from "emailjs-com";
import React from 'react';
import fire from './fire';
import {Link} from 'react-router-dom';
import { BrowserRouter as Router, Switch, Route,Redirect } from "react-router-dom"; 
import './contactform.css';
import svg from '../img/order.png'
function ContactUs() {

    function sendEmail(e) {
        e.preventDefault();

    emailjs.sendForm('service_72b0qdh', 'template_uceqw7k', e.target, 'user_NmjjDR3E0BFJ3x3zLmlIa')
        .then((result) => {
            console.log(result.text);
        }, (error) => {
            console.log(error.text);
        });
        e.target.reset()
    }

    function logout() {
        fire.auth().signOut();
        console.log("logout");
        {/* <Redirect to="/Login"></Redirect> */}
      }

    return(
        <div className="des-container">
        <div className="design">                
        <div className="content">                    
        <h4>Have SomeThing For Us!</h4>                    
        </div>                   
             <div className="svg">                       
             <img  id="svg" src={svg}  alt="svg"></img>                    
            </div>                              
         </div>
            <div className="container">
                <br></br>
               
            <div className="title">Order Booking</div>
            <div className="content">
             <form onSubmit={sendEmail}>
                <div className="user-details">
                <div className="input-box">
                        <span className="details"></span>
                        <input type="text" placeholder="Enter your name" name="name" required></input>
                    </div>
                    <div className="input-box">
                        <span className="details"></span>
                        <input type="text" placeholder="Enter your style" name="type" required></input>
                    </div>
                    <div className="input-box">
                        <span className="details"></span>
                        <input type="text" placeholder="Enter your email" name="email" required></input>
                    </div>
                    <div className="input-box">
                        <span className="details"></span>
                        <input type="text" placeholder="Enter your quantity" name="quantity" required></input>
                    </div>
                    <div className="input-box">
                        <span className="details"></span>
                        <input type="text" placeholder="Enter your rate" name="rate" required></input>
                    </div>
                    <div className="input-box">
                        <span className="details"></span>
                        <input type="text" placeholder="Enter your remarks" name="message" required></input>
                    </div>
                    </div>
                    
                    <div className="col-8 pt-3 mx-auto">
                    <input type="submit" className="btn btn-info" value="Send Message"></input>
                </div>
                <br></br><br></br><br></br><br></br><br></br><br></br>
      </form>

      
      <div style={{textAlign: 'center'}}>
        <h1>You Are Logged In</h1>
        {/* <button onClick = {logout}>Logout</button> */}
        <Link class="nav-link" onClick = {logout} to="/Login">Logout</Link>
      </div>
    </div>
  </div>
  </div>
            
    );
}


export default  ContactUs;
